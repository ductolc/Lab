package lab6;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.SimpleTagSupport;

public class CustomTagAttribute extends SimpleTagSupport {
	private String ten;
	private String kieungay;
	

	public String getTen() {
		return ten;
	}


	public void setTen(String ten) {
		this.ten = ten;
	}


	public String getKieungay() {
		return kieungay;
	}


	public void setKieungay(String kieungay) {
		this.kieungay = kieungay;
	}


	@Override
	public void doTag() throws JspException{
		JspWriter out = getJspContext().getOut();
		try {
			if(ten.isEmpty())
				ten = "Khong ten";
			if(kieungay.isEmpty())
				kieungay = "dd/MM/yyyy";
			Date ngay = new Date();
			String chuoingay = new SimpleDateFormat(kieungay).format(ngay);
			out.println("<h2>Hom nay ngay"+chuoingay+"</h2>");
			out.println("<h1>Chao mung ban"+ten+"</h1>");
		} catch (java.io.IOException e) {
			throw new JspException("Error in CustomTagAttribute tag", e);
		}
	}
}
