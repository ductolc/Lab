package control;

import java.beans.Statement;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sun.org.apache.xalan.internal.xsltc.compiler.sym;

/**
 * Servlet implementation class SearchAccount
 */
@WebServlet("/SearchAccount")
public class SearchAccount extends HttpServlet {
	private static final long serialVersionUID = 1L;
      
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SearchAccount() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();
		out.println("<html><head><title>SearchAccount</title></head>");
		out.println("<body><h1>Ket qua tra dien thoai cua ban: </h1>");
		out.println("<table border=1 cellPadding=1 cellSpacing=1");
		String tentbao=request.getParameter("txtthuebao");
		
		String newSQL = "select * from CUSTOMER";
		if(tentbao != null && tentbao.length() != 0) {
			newSQL = newSQL+ " where TenThueBao like '%" + tentbao +"%'";
			
		}
		String conStr ="jdbc:sqlserver://DESKTOP-5B10Q33\\SQLEXPRESS:1433; databaseName=QLdienthoai";
		java.sql.Statement stmt = null;
		ResultSet rs = null;
		try {
			Connection con = null;
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			con = DriverManager.getConnection(conStr, "sa","123");
			stmt = con.createStatement();
			rs = stmt.executeQuery(newSQL);
			out.println("<tr><th>So thu tu</th><th>Ten thue bao</th><th>So dien thoai</th><th>Dia chi</th></tr>");
			if(rs != null) {
				for( int i=1; rs.next();i++) {
					out.println("<tr>" + "<td>" + i + "</td>" + "<td>" + rs.getString(2) + "</td>"
							+"<td>" + rs.getString(3) + "</td>"
							+"<td>"+ rs.getString(4) + "</td></tr>\n");
				}
			}
			out.println("</table>");
			rs.close();
			stmt.close();
			con.close();
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
	}

}
