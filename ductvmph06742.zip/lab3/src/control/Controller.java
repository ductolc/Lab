package control;

import java.io.IOException;
import java.io.PrintWriter;
import control.LoginBean;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.tomcat.util.descriptor.web.LoginConfig;

import com.sun.corba.se.spi.orbutil.fsm.Guard.Result;

/**
 * Servlet implementation class Controller
 */
@WebServlet("/Controller")
public class Controller extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
	final private String errorPage="fail.jsp";
	final private String homePage="index.jsp";
	final private String welcomePage="welcome.jsp";
	final private String registerPage="register.jsp";
	final private String showPage="show.jsp";
	
    public Controller() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();
		try {
			String action = request.getParameter("btaction");
			if(action.equals("Login")) {
				String username = request.getParameter("txtusername");
				String password = request.getParameter("txtpass");
				LoginBean login = new LoginBean();
				boolean result = login.checkLogin(username, password);
				String url=errorPage;
				if(result) {
					HttpSession session = request.getSession(true);
					session.setAttribute("USER", username);
					url = welcomePage;
				}
				RequestDispatcher rd = request.getRequestDispatcher(url);
				rd.forward(request, response);
				
			}else if(action.equals("tryAgain")){
				RequestDispatcher rd = request.getRequestDispatcher(homePage);
				rd.forward(request, response);
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		
	}

}
